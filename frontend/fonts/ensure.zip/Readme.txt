Please before commercial use of this font, prior donation is necessary to my Dafont Paypal account.
Anyway consider donating to encourage further development and new fonts! Donations accepted through Dafont.com Paypal button address.

Thank's, I hope my work will suit your project, be positive, keep creating!
Manuel Ramos

www.infinitismo.com